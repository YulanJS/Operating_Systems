/*
 * HelloWorld.c
 *
 *  Created on: Sep 3, 2017
 *      Author: craig
 */

#include <stdio.h> 

int main()
{
	printf("\nHello World!");
	return 0;
}

